# worms

Es compilar:
es necesaio tener instalado Box2d 2.3 y SDL 1.2 (SDL_Image SDL_ttf)
ejecutar "make clean"
y luego "make all"

para ejecutar:
correr en una consola
"./server <puerto>"
  
 correr en otra consola
 "./client <host-name> <puerto>"
  
 para jugar:
 moverse con las flechas
 saltar para atras con backwars
 para ver el menu de armas mover el cursor cerca de la esquina superior izquierda
 aumentar la potencia de un arma con espacio
 disparar soltando espacio o con w
 
 
